import cv2
from ar_module import overlay_ar
from utils import get_user_choice

def main():
    print("Welcome to VirtualFitAR")

    # Get user choice for the item to try on
    choice, item_type = get_user_choice()
    print(f"User choice: {choice}")

    if choice:
        # Open the webcam
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Error: Could not open webcam")
            return

        print("Webcam opened successfully")

        while True:
            ret, frame = cap.read()
            if not ret:
                print("Error: Failed to read frame from webcam")
                break

            # Apply AR overlay based on user choice and item type
            ar_frame = overlay_ar(frame, choice, item_type)
            cv2.imshow("VirtualFitAR", ar_frame)

            # Exit the loop when 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # Release the camera and close windows
        cap.release()
        cv2.destroyAllWindows()
    else:
        print("No valid option selected.")

if __name__ == "__main__":
    main()