import cv2

# Load the Haar Cascade for face detection
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

def overlay_ar(frame, asset_path, item_type):
    print(f"Loading AR asset from: {asset_path}")
    asset = cv2.imread(asset_path, -1)  # Load PNG with alpha channel

    if asset is None:
        print("Error: Failed to load AR asset.")
        return frame

    print("AR asset loaded successfully")

    # Convert the frame to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(100, 100))

    for (x, y, w, h) in faces:
        if item_type == "sunglasses":
            # Resize the sunglasses to fit the width of the face
            resized_asset = cv2.resize(asset, (w, int(h / 2)))
            y_offset = y + int(h * 0.25)  # Position sunglasses over the eyes

        elif item_type == "hat":
            # Resize the hat to fit the width of the face
            resized_asset = cv2.resize(asset, (w, int(h / 2)))
            y_offset = y - int(h / 2)  # Position hat above the head

        elif item_type == "tshirt":
            # Resize the T-shirt to be wider and taller than the face
            resized_asset = cv2.resize(asset, (w * 2, h * 2))
            y_offset = y + h  # Position the T-shirt below the face

        # Get the new dimensions of the resized asset
        asset_height, asset_width = resized_asset.shape[:2]

        # Calculate the region where the asset will be placed
        x_offset = x

        # Ensure that the asset doesn't go out of the frame
        if y_offset < 0:
            y_offset = 0  # Prevent placing the asset out of bounds at the top
        if y_offset + asset_height > frame.shape[0]:
            asset_height = frame.shape[0] - y_offset
            resized_asset = resized_asset[:asset_height, :]

        if x_offset + asset_width > frame.shape[1]:
            asset_width = frame.shape[1] - x_offset
            resized_asset = resized_asset[:, :asset_width]

        # Overlay the asset on the frame
        for c in range(0, 3):
            frame[y_offset:y_offset + asset_height, x_offset:x_offset + asset_width, c] = \
                resized_asset[:, :, c] * (resized_asset[:, :, 3] / 255.0) + \
                frame[y_offset:y_offset + asset_height, x_offset:x_offset + asset_width, c] * (1.0 - resized_asset[:, :, 3] / 255.0)

    return frame