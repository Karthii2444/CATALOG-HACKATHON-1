def get_user_choice():
    print("Select a product to try on:")
    print("1. T-shirt")
    print("2. Sunglasses")
    print("3. Hat")
    choice = input("Enter the number: ")

    if choice == "1":
        return "assets/clothing/tshirt.png", "tshirt"
    elif choice == "2":
        return "assets/accessories/sunglasses.png", "sunglasses"
    elif choice == "3":
        return "assets/accessories/hat.png", "hat"
    else:
        return None, None